// watchdog
package main

import (
	"fmt"
	"time"

	ctask "./wd"
)

func main() {
	tasker := ctask.NewTasker()
	for i := 0; i < 5; i++ {
		taskId := fmt.Sprintf("userTask-%d", i)
		tasker.AddTask(5, 20, taskId, userTask)
	}
	tasker.RunTask()
}

func userTask(ch chan string) {
	defer func() {
		if err := recover(); err != nil {
			fmt.Println("异常信息为:", err)
		}
	}()
	for {
		ctask.TaskContor(ch)
		ctask.TaskFeedDog(ch)
		time.Sleep(time.Second * 10)
	}
}
